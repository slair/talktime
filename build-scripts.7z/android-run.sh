#!/bin/sh
#-*- coding: utf-8 -*-

# Exit the script on errors:
set -e
trap 'echo "$0 FAILED at line ${LINENO}"' ERR
# Catch unitialized variables:
set -u

adir=$(pwd)
source_dir=${1}

#~ ~/work/android/android-build.sh ${source_dir}

cd ${source_dir}
while true; do
	project_dir=`pwd`
	if [ -r "set-app-env.sh" ]; then
		break
	fi
	if [ ${project_dir} == "/" ]; then
		echo "No project found for this source"
		exit
	fi
	cd ..
done
pwd
source ${adir}/set-android-env.sh
source ./set-app-env.sh

${ADB} shell am start -n ${PACKAGE}/${PACKAGE}.${MAIN_CLASS}
