#!/bin/sh

~/opt/Android/emulator/emulator -avd Pixel_3a_API_34_extension_level_7_x86_64 2>&1 > /dev/null &
