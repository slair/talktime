#!/bin/sh
reset
. ./android-clean.sh talktime 2>&1 | cz.py
. ./android-build.sh talktime 2>&1 | cz.py
