#!/bin/sh
#-*- coding: utf-8 -*-

# Exit the script on errors:
set -e
trap 'echo "$0 FAILED at line ${LINENO}"' ERR
# Catch unitialized variables:
set -u

adir=$(pwd)
source_dir=${1}

${adir}/android-clean.sh ${source_dir}

cd ${source_dir}
while true; do
	project_dir=`pwd`
	if [ -r "set-app-env.sh" ]; then
		break
	fi
	if [ ${project_dir} == "/" ]; then
		echo "No project found for this source"
		exit
	fi
	cd ..
done

source ${adir}/set-android-env.sh
source ./set-app-env.sh

echo -n "Creating R.java ... "
#~ ${AAPT_PATH} package -f -m -S ${DEV_HOME}/res -J ${DEV_HOME}/src -M ${DEV_HOME}/AndroidManifest.xml -I ${ANDROID_JAR}
aapt package -f -m -S ${DEV_HOME}/res -J ${DEV_HOME}/src -M ${DEV_HOME}/AndroidManifest.xml -I ${ANDROID_JAR}
echo "done."

echo -n "Compiling classes ... "
${JAVA_HOME}/bin/javac -version
${JAVA_HOME}/bin/javac -d ${DEV_HOME}/obj -cp ${ANDROID_JAR} -sourcepath ${DEV_HOME}/src ${DEV_HOME}/src/${PACKAGE_PATH}/*.java -source 1.7 -target 1.7
#~ ${JAVA_HOME}/bin/javac -d ${DEV_HOME}/obj -cp ${ANDROID_JAR} -sourcepath ${DEV_HOME}/src ${DEV_HOME}/src/${PACKAGE_PATH}/*.java
echo "done."

echo -n "Converting classes to dex ... "
${DX_PATH} --dex --output=${DEV_HOME}/bin/classes.dex ${DEV_HOME}/obj
echo "done."

echo -n "Creating ${DEV_HOME}/bin/${APK_NAME}.unsigned.apk ... "
${AAPT_PATH} package -f -M ${DEV_HOME}/AndroidManifest.xml -S ${DEV_HOME}/res -I ${ANDROID_JAR} -F ${DEV_HOME}/bin/${APK_NAME}.unsigned.apk ${DEV_HOME}/bin
echo "done."

if [ ! -r ${DEV_HOME}/AndroidTest.keystore ]; then
	echo -n "Generating ${DEV_HOME}/AndroidTest.keystore ... "
	${JAVA_HOME}/bin/keytool -genkey -validity 10000 -dname "CN=AndroidDebug, O=Android, C=US" -keystore ${DEV_HOME}/AndroidTest.keystore -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048
	echo "done."
fi

echo -n "Signing to ${DEV_HOME}/bin/${APK_NAME}.signed.apk ... "
${JAVA_HOME}/bin/jarsigner -sigalg SHA1withRSA -digestalg SHA1 -keystore ${DEV_HOME}/AndroidTest.keystore -storepass android -keypass android -signedjar ${DEV_HOME}/bin/${APK_NAME}.signed.apk ${DEV_HOME}/bin/${APK_NAME}.unsigned.apk androiddebugkey >/dev/null
echo "done."
ls -lh bin/
