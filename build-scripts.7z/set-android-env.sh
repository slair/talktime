#!/bin/sh
#-*- coding: utf-8 -*-

# Exit the script on errors:
set -e
trap 'echo "$0 FAILED at line ${LINENO}"' ERR
# Catch unitialized variables:
set -u

# Первое, что мы сделаем для удобства и краткости — создадим
# специальные переменные, в которых будем хранить пути.
# Для начала — определим наши основные директории.
# Вам нужно заменить пути к JDK и Android SDK на те, которые у вас.
#~ export JAVA_HOME=/usr/lib/jdk1.8.0_25
#~ export JAVA_HOME=/usr/lib/jdk1.7.0_75
export JAVA_HOME=/opt/android-studio/jbr
#~ export JAVA_HOME=/opt/jdk-21.0.2
#~ export ANDROID_HOME=/home/slair/media/apps/android/sdk
export DEV_HOME=.

# Далее — пути непосредственно к программам.
# Я рекомендую вам просмотреть каталоги ваших SDK и убедится в том,
# что всё на месте. Также подкорректировать версии,
# которые присутствуют в путях.
export ANDROID_BTV=30.0.3
export ANDROID_PV=30
export AAPT_PATH=${ANDROID_HOME}/build-tools/${ANDROID_BTV}/aapt
export DX_PATH=${ANDROID_HOME}/build-tools/${ANDROID_BTV}/dx
export ANDROID_JAR=${ANDROID_HOME}/platforms/android-${ANDROID_PV}/android.jar
export ADB=${ANDROID_HOME}/platform-tools/adb
# Между прочим, в более старых версиях утилита aapt
# находилась в platform-tools — и я не исключаю
# что она и\или другие могут слинять куда-нибудь ещё.
# Так что будьте внимательны. Если вы всё правильно сверите сейчас — то
# остальная часть статьи должна пройти гладко.
