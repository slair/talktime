#!/bin/sh
#-*- coding: utf-8 -*-

# Exit the script on errors:
set -e
trap 'echo "$0 FAILED at line ${LINENO}"' ERR
# Catch unitialized variables:
set -u

adir=$(pwd)
source_dir=${1}

cd ${source_dir}

while true; do
	project_dir=`pwd`
	if [ -r "set-app-env.sh" ]; then
		break
	fi
	if [ ${project_dir} == "/" ]; then
		echo "${source_dir} : No project found for this source"
		exit
	fi
	cd ..
done

source ${adir}/set-android-env.sh
source ./set-app-env.sh

echo -n "${project_dir} : Cleaning ... "
rm bin/*.apk 2>/dev/null|| true
rm bin/*.dex 2>/dev/null || true
rm obj/${PACKAGE_PATH}/*.class 2>/dev/null || true
rm ${DEV_HOME}/src/${PACKAGE_PATH}/R.java 2>/dev/null || true
find ./obj -iname '*.class' -exec rm {} \;
echo "done."
